"use client";

export function TestimonialsSection() {
  return (
    <section className="relative py-32 lg:py-40 border-t border-foreground/10">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="max-w-4xl">
          <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Use Cases
          </span>
          <h2 className="text-4xl lg:text-6xl font-display tracking-tight mb-12">
            Remote infrastructure
            <br />
            <span className="text-muted-foreground">where satellites dominate costs.</span>
          </h2>
          
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="p-6 border border-foreground/10">
              <h3 className="font-display text-2xl mb-3">Remote Infrastructure</h3>
              <p className="text-muted-foreground leading-relaxed">Offshore platforms, pipeline networks, island operations, remote substations. Anywhere satellite backhaul costs dominate.</p>
            </div>
            <div className="p-6 border border-foreground/10">
              <h3 className="font-display text-2xl mb-3">Continuous AI Monitoring</h3>
              <p className="text-muted-foreground leading-relaxed">Base Layer latents stream 24/7 for real-time anomaly detection. No gaps. No missed events.</p>
            </div>
            <div className="p-6 border border-foreground/10">
              <h3 className="font-display text-2xl mb-3">Legal-Grade Forensics</h3>
              <p className="text-muted-foreground leading-relaxed">When an incident occurs, fetch the Enhancement Layer. Reconstruct full human-viewable video. Court-admissible.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
