---
name: Technical Schematic
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1b1b1b'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303030'
  inverse-on-surface: '#f1f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e3e2e2'
  on-secondary-container: '#646464'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1b1b'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e3e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1b1b1b'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1b1b1b'
  surface-variant: '#e2e2e2'
typography:
  headline-lg:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-sm:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: '1'
    letterSpacing: 0.05em
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  hairline: 1px
---

## Brand & Style

This design system is built on the visual language of engineering blueprints and architectural drafting. It prioritizes precision, clarity, and the raw beauty of structural lines over decorative elements. The target audience is analytical, detail-oriented, and values utility and high-efficiency interfaces.

The aesthetic follows a **High-Contrast Minimalist** approach with a **Technical Drawing** influence. It utilizes white space as a functional tool rather than just a breather, treating the UI as a canvas for data and structured information. Every element feels deliberate, as if plotted with a rapidograph pen. There are no shadows, no gradients, and no rounded corners—only pure geometric intent and hairline-thin strokes.

## Colors

The palette is strictly monochromatic, leaning into the stark contrast of an ink-on-paper schematic. 

- **Primary (#000000):** Used for all structural lines, heavy borders, and primary typography. It represents the "final ink" of a drawing.
- **Secondary (#737373):** Used for annotations, dimensions, and secondary metadata.
- **Background (#FFFFFF):** A pure, clinical white that serves as the drafting surface.
- **Border (#E5E5E5):** Used for lighter grid lines and non-interactive structural guides.

Avoid any use of hue; if a state change is required (e.g., error or success), use line weight, icon style, or fill patterns (like cross-hatching) instead of color.

## Typography

Typography in this design system is divided between **Technical Data (Monospaced)** and **Narrative Information (Sans-serif)**.

- **JetBrains Mono** is used for all headings, labels, buttons, and numerical data. It evokes the feel of a plotter or a stencil, ensuring that technical details are legible and feel systematically aligned.
- **Geist** is used for body copy and descriptive text. Its clean, neutral geometry complements the mono-spaced elements without competing for attention.

All labels should ideally be uppercase to mimic engineering notes. Line heights are kept tight to maintain the compact, information-dense feel of a datasheet.

## Layout & Spacing

The layout is built on a **Fixed Grid** system that mirrors the structure of graph paper. 

- **Grid:** Use a 12-column grid for desktop and a 4-column grid for mobile. 
- **Gutters:** Columns are separated by 16px gutters, which are often visually reinforced by vertical 1px hairlines.
- **Rhythm:** All spacing (padding/margins) must be multiples of the 4px base unit. 
- **Alignment:** Elements should be top-left aligned by default, emphasizing the starting point of a drawing. 

Containers and sections should be separated by visible 1px borders rather than whitespace alone, creating a "boxed" or "nested" schematic look.

## Elevation & Depth

This design system is strictly **Flat**. There are no shadows or simulated Z-axis heights. 

Depth is communicated through **Line Weight and Layering**:
- **Level 0 (Background):** Pure white canvas.
- **Level 1 (Containers):** Defined by a 1px solid black border.
- **Level 2 (Overlays/Modals):** Defined by a 2px solid black border with a white fill to obscure background elements. 

Interactivity is indicated by inversions (flipping background and foreground colors) or by increasing a stroke weight from 1px to 2px.

## Shapes

The shape language is defined by **Absolute Rectilinearity**. 

Every element—buttons, cards, input fields, dropdowns—must have a `0px` border radius. There are no exceptions for circles or curves unless they represent specific data (like a pie chart). This lack of rounding reinforces the "unrefined," structural aesthetic of a technical drawing. Decorative elements like "cross-hair" marks at the corners of containers can be used to emphasize the drafting theme.

## Components

- **Buttons:** High-contrast outlines (1px or 2px). On hover, the button should invert (Black background, White text). Labels are always in monospaced uppercase.
- **Input Fields:** A simple bottom-border (2px) or a full 1px box. Labels are positioned above the field in a small monospaced font, reminiscent of a form ID.
- **Cards/Modules:** Sharp-edged boxes with 1px borders. If the card contains a header, separate it from the body with a horizontal 1px line.
- **Chips/Tags:** Small rectangular boxes with monospaced text. No rounded corners. Use a 1px border.
- **Lists:** Rows separated by 1px horizontal lines. Use a small "tick" mark or a bullet point that looks like a drafting dot.
- **Checkboxes/Radio Buttons:** Square boxes (no circles). A selected state is indicated by a solid black fill or an "X" mark, never a checkmark.
- **Data Tables:** Heavy headers (2px bottom border) and light row separators (1px). Monospaced font for all cell contents to ensure vertical alignment of digits.